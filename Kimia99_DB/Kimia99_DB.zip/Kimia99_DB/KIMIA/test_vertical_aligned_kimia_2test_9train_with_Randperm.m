clear all
load randperm_Kimia.mat
TR_SIZE=9;
for trial=1:10,
    trial
   
    for i=1:9,
        for tr_index=1:TR_SIZE
            trainset{i}{tr_index}=uint8(imread(sprintf('trainimage%d_%d.png',i,FQ{trial}(i,tr_index))));
        end
    end;
    TPR_CM{trial}=zeros(9,9);
    TNR_CM{trial}=zeros(9,9);
    PPV_CM{trial}=zeros(9,9);
    NPV_CM{trial}=zeros(9,9);
    
    FPR_CM{trial}=zeros(9,9);
    FNR_CM{trial}=zeros(9,9);
    FDR_CM{trial}=zeros(9,9);
    FOR_CM{trial}=zeros(9,9);
    
     TS_CM{trial}=zeros(9,9);
     ACC_CM{trial}=zeros(9,9);
     BA_CM{trial}=zeros(9,9);
     F1_CM{trial}=zeros(9,9);
            
     MCC_CM{trial}=zeros(9,9);
     FM_CM{trial}=zeros(9,9);
     MK_CM{trial}=zeros(9,9);
     BM_CM{trial}=zeros(9,9);
     VOTE_CM{trial}=zeros(9,9);
    
    
    for i=1:9,
        
        for j=1:(11-TR_SIZE),
            testimage=uint8(imread(sprintf('trainimage%d_%d.png',i,FQ{trial}(i,j+TR_SIZE))));
            for k=1:9
                st1(k)=confmat.metrics(trainset{k}{1},testimage,1);
                st2(k)=confmat.metrics(trainset{k}{2},testimage,1);
                st3(k)=confmat.metrics(trainset{k}{3},testimage,1);
                st4(k)=confmat.metrics(trainset{k}{4},testimage,1);
                st5(k)=confmat.metrics(trainset{k}{5},testimage,1);
                st6(k)=confmat.metrics(trainset{k}{6},testimage,1);
                st7(k)=confmat.metrics(trainset{k}{7},testimage,1);
                st8(k)=confmat.metrics(trainset{k}{8},testimage,1);
                st9(k)=confmat.metrics(trainset{k}{9},testimage,1);
            end
            
            TPRdetect(i,j)=find(max([[st1(:).TPR];[st2(:).TPR];...
                [st3(:).TPR];[st4(:).TPR];[st5(:).TPR];[st6(:).TPR];[st7(:).TPR];[st8(:).TPR];[st9(:).TPR]])==...
                max(max([[st1(:).TPR];[st2(:).TPR];[st3(:).TPR];...
                [st4(:).TPR];[st5(:).TPR];[st6(:).TPR];[st7(:).TPR];[st8(:).TPR];[st9(:).TPR]])),1);
            vote(1)=TPRdetect(i,j);
            TPR_CM{trial}(i,vote(1))=TPR_CM{trial}(i,vote(1))+1;
            TNRdetect(i,j)=find(max([[st1(:).TNR];[st2(:).TNR];...
                [st3(:).TNR];[st4(:).TNR];[st5(:).TNR];[st6(:).TNR];[st7(:).TNR];[st8(:).TNR];[st9(:).TNR]])==...
                max(max([[st1(:).TNR];[st2(:).TNR];[st3(:).TNR];...
                [st4(:).TNR];[st5(:).TNR];[st6(:).TNR];[st7(:).TNR];[st8(:).TNR];[st9(:).TNR]])),1);
            vote(2)=TNRdetect(i,j);
            TNR_CM{trial}(i,vote(2))=TNR_CM{trial}(i,vote(2))+1;
            PPVdetect(i,j)=find(max([[st1(:).PPV];[st2(:).PPV];...
                [st3(:).PPV];[st4(:).PPV];[st5(:).PPV];[st6(:).PPV];[st7(:).PPV];[st8(:).PPV];[st9(:).PPV]])==...
                max(max([[st1(:).PPV];[st2(:).PPV];[st3(:).PPV];...
                [st4(:).PPV];[st5(:).PPV];[st6(:).PPV];[st7(:).PPV];[st8(:).PPV];[st9(:).PPV]])),1);
            vote(3)=PPVdetect(i,j);
            PPV_CM{trial}(i,vote(3))=PPV_CM{trial}(i,vote(3))+1;
            NPVdetect(i,j)=find(max([[st1(:).NPV];[st2(:).NPV];...
                [st3(:).NPV];[st4(:).NPV];[st5(:).NPV];[st6(:).NPV];[st7(:).NPV];[st8(:).NPV];[st9(:).NPV]])==...
                max(max([[st1(:).NPV];[st2(:).NPV];[st3(:).NPV];...
                [st4(:).NPV];[st5(:).NPV];[st6(:).NPV];[st7(:).NPV];[st8(:).NPV];[st9(:).NPV]])),1);
            vote(4)=NPVdetect(i,j);
            NPV_CM{trial}(i,vote(4))=NPV_CM{trial}(i,vote(4))+1;
            
            FPRdetect(i,j)=find(min([[st1(:).FPR];[st2(:).FPR];...
                [st3(:).FPR];[st4(:).FPR];[st5(:).FPR];[st6(:).FPR];[st7(:).FPR];[st8(:).FPR];[st9(:).FPR]])==...
                min(min([[st1(:).FPR];[st2(:).FPR];[st3(:).FPR];...
                [st4(:).FPR];[st5(:).FPR];[st6(:).FPR];[st7(:).FPR];[st8(:).FPR];[st8(:).TPR];[st9(:).FPR]])),1);
            vote(5)=FPRdetect(i,j);
            FPR_CM{trial}(i,vote(5))=FPR_CM{trial}(i,vote(5))+1;
            FNRdetect(i,j)=find(min([[st1(:).FNR];[st2(:).FNR];...
                [st3(:).FNR];[st4(:).FNR];[st5(:).FNR];[st6(:).FNR];[st7(:).FNR];[st8(:).FNR];[st9(:).FNR]])==...
                min(min([[st1(:).FNR];[st2(:).FNR];[st3(:).FNR];...
                [st4(:).FNR];[st5(:).FNR];[st6(:).FNR];[st7(:).FNR];[st8(:).FNR];[st9(:).FNR]])),1);
            vote(6)=FNRdetect(i,j);
            FNR_CM{trial}(i,vote(6))=FNR_CM{trial}(i,vote(6))+1;
            FDRdetect(i,j)=find(min([[st1(:).FDR];[st2(:).FDR];...
                [st3(:).FDR];[st4(:).FDR];[st5(:).FDR];[st6(:).FDR];[st7(:).FDR];[st8(:).FDR];[st9(:).FDR]])==...
                min(min([[st1(:).FDR];[st2(:).FDR];[st3(:).FDR];...
                [st4(:).FDR];[st5(:).FDR];[st6(:).FDR];[st7(:).FDR];[st8(:).FDR];[st9(:).FDR]])),1);
            vote(7)=FDRdetect(i,j);
            FDR_CM{trial}(i,vote(7))=FDR_CM{trial}(i,vote(7))+1;
            FORdetect(i,j)=find(min([[st1(:).FOR];[st2(:).FOR];...
                [st3(:).FOR];[st4(:).FOR];[st5(:).FOR];[st6(:).FOR];[st7(:).FOR];[st8(:).FOR];[st9(:).FOR]])==...
                min(min([[st1(:).FOR];[st2(:).FOR];[st3(:).FOR];...
                [st4(:).FOR];[st5(:).FOR];[st6(:).FOR];[st7(:).FOR];[st8(:).FOR];[st9(:).FOR]])),1);
            vote(8)=FORdetect(i,j);
            FOR_CM{trial}(i,vote(8))=FOR_CM{trial}(i,vote(8))+1;
            
            TSdetect(i,j)=find(max([[st1(:).TS];[st2(:).TS];...
                [st3(:).TS];[st4(:).TS];[st5(:).TS];[st6(:).TS];[st7(:).TS];[st8(:).TS];[st9(:).TS]])==max(max([[st1(:).TS];...
                [st2(:).TS];[st3(:).TS];[st4(:).TS];[st5(:).TS];[st6(:).TS];[st7(:).TS];[st8(:).TS];[st9(:).TS]])),1);
            vote(9)=TSdetect(i,j);
            TS_CM{trial}(i,vote(9))=TS_CM{trial}(i,vote(9))+1;
            ACCdetect(i,j)=find(max([[st1(:).ACC];[st2(:).ACC];...
                [st3(:).ACC];[st4(:).ACC];[st5(:).ACC];[st6(:).ACC];[st7(:).ACC];[st8(:).ACC];[st9(:).ACC]])==max(max([[st1(:).ACC];...
                [st2(:).ACC];[st3(:).ACC];[st4(:).ACC];[st5(:).ACC];[st6(:).ACC];[st7(:).ACC];[st8(:).ACC];[st9(:).ACC]])),1);
            vote(10)=ACCdetect(i,j);
            ACC_CM{trial}(i,vote(10))=ACC_CM{trial}(i,vote(10))+1;
            BAdetect(i,j)=find(max([[st1(:).BA];[st2(:).BA];...
                [st3(:).BA];[st4(:).BA];[st5(:).BA];[st6(:).BA];[st7(:).BA];[st8(:).BA];[st9(:).BA]])==max(max([[st1(:).BA];...
                [st2(:).BA];[st3(:).BA];[st4(:).BA];[st5(:).BA];[st6(:).BA];[st7(:).BA];[st8(:).BA];[st9(:).BA]])),1);
            vote(11)=BAdetect(i,j);
            BA_CM{trial}(i,vote(11))=BA_CM{trial}(i,vote(11))+1;
            F1detect(i,j)=find(max([[st1(:).F1];[st2(:).F1];...
                [st3(:).F1];[st4(:).F1];[st5(:).F1];[st6(:).F1];[st7(:).F1];[st8(:).F1];[st9(:).F1]])==max(max([[st1(:).F1];...
                [st2(:).F1];[st3(:).F1];[st4(:).F1];[st5(:).F1];[st6(:).F1];[st7(:).F1];[st8(:).F1];[st9(:).F1]])),1);
            vote(12)=F1detect(i,j);
            F1_CM{trial}(i,vote(12))=F1_CM{trial}(i,vote(12))+1;
            
            MCCdetect(i,j)=find(max([[st1(:).MCC];[st2(:).MCC];...
                [st3(:).MCC];[st4(:).MCC];[st5(:).MCC];[st6(:).MCC];[st7(:).MCC];[st8(:).MCC];[st9(:).MCC]])==max(max([[st1(:).MCC];...
                [st2(:).MCC];[st3(:).MCC];[st4(:).MCC];[st5(:).MCC];[st6(:).MCC];[st7(:).MCC];[st8(:).MCC];[st9(:).MCC]])),1);
            vote(13)=MCCdetect(i,j);
            MCC_CM{trial}(i,vote(13))=MCC_CM{trial}(i,vote(13))+1;
            FMdetect(i,j)=find(max([[st1(:).FM];[st2(:).FM];...
                [st3(:).FM];[st4(:).FM];[st5(:).FM];[st6(:).FM];[st7(:).FM];[st8(:).FM];[st9(:).FM]])==max(max([[st1(:).FM];...
                [st2(:).FM];[st3(:).FM];[st4(:).FM];[st5(:).FM];[st6(:).FM];[st7(:).FM];[st8(:).FM];[st9(:).FM]])),1);
            vote(14)=FMdetect(i,j);
            FM_CM{trial}(i,vote(14))=FM_CM{trial}(i,vote(14))+1;
            MKdetect(i,j)=find(max([[st1(:).MK];[st2(:).MK];...
                [st3(:).MK];[st4(:).MK];[st5(:).MK];[st6(:).MK];[st7(:).MK];[st8(:).MK];[st9(:).MK]])==max(max([[st1(:).MK];...
                [st2(:).MK];[st3(:).MK];[st4(:).MK];[st5(:).MK];[st6(:).MK];[st7(:).MK];[st8(:).MK];[st9(:).MK]])),1);
            vote(15)=MKdetect(i,j);
            MK_CM{trial}(i,vote(15))=MK_CM{trial}(i,vote(15))+1;
            BMdetect(i,j)=find(max([[st1(:).BM];[st2(:).BM];...
                [st3(:).BM];[st4(:).BM];[st5(:).BM];[st6(:).BM];[st7(:).BM];[st8(:).BM];[st9(:).BM]])==max(max([[st1(:).BM];...
                [st2(:).BM];[st3(:).BM];[st4(:).BM];[st5(:).BM];[st6(:).BM];[st7(:).BM];[st8(:).BM];[st9(:).BM]])),1);
            vote(16)=BMdetect(i,j);
            BM_CM{trial}(i,vote(16))=BM_CM{trial}(i,vote(16))+1;
            VOTEdetect(i,j)=mode(vote);
            VOTE_CM{trial}(i,mode(vote))=VOTE_CM{trial}(i,mode(vote))+1;
        end
         TPR_accuracy(trial,i)=TPR_CM{trial}(i,i)*100/2;
         TNR_accuracy(trial,i)=TNR_CM{trial}(i,i)*100/2;
         PPV_accuracy(trial,i)=PPV_CM{trial}(i,i)*100/2;
         NPV_accuracy(trial,i)=NPV_CM{trial}(i,i)*100/2;
    
         FPR_accuracy(trial,i)=FPR_CM{trial}(i,i)*100/2;
         FNR_accuracy(trial,i)=FNR_CM{trial}(i,i)*100/2;
         FDR_accuracy(trial,i)=FDR_CM{trial}(i,i)*100/2;
         FOR_accuracy(trial,i)=FOR_CM{trial}(i,i)*100/2;
    
         TS_accuracy(trial,i)=TS_CM{trial}(i,i)*100/2;
         ACC_accuracy(trial,i)=ACC_CM{trial}(i,i)*100/2;
         BA_accuracy(trial,i)=BA_CM{trial}(i,i)*100/2;
         F1_accuracy(trial,i)=F1_CM{trial}(i,i)*100/2;
            
         MCC_accuracy(trial,i)=MCC_CM{trial}(i,i)*100/2;
         FM_accuracy(trial,i)=FM_CM{trial}(i,i)*100/2;
         BM_accuracy(trial,i)=BM_CM{trial}(i,i)*100/2;
         MK_accuracy(trial,i)=MK_CM{trial}(i,i)*100/2;
     
         VOTE_accuracy(trial,i)=VOTE_CM{trial}(i,i)*100/2;
    end
end

TABLO(1,:)=round(mean(TPR_accuracy),1)
TABLO(2,:)=round(mean(TNR_accuracy),1)
TABLO(3,:)=round(mean(PPV_accuracy),1)
TABLO(4,:)=round(mean(NPV_accuracy),1)

TABLO(5,:)=round(mean(FPR_accuracy),1)
TABLO(6,:)=round(mean(FNR_accuracy),1)
TABLO(7,:)=round(mean(FDR_accuracy),1)
TABLO(8,:)=round(mean(FOR_accuracy),1)

TABLO(9,:)=round(mean(TS_accuracy),1)
TABLO(10,:)=round(mean(ACC_accuracy),1)
TABLO(11,:)=round(mean(BA_accuracy),1)
TABLO(12,:)=round(mean(F1_accuracy),1)

TABLO(13,:)=round(mean(MCC_accuracy),1)
TABLO(14,:)=round(mean(FM_accuracy),1)
TABLO(15,:)=round(mean(BM_accuracy),1)
TABLO(16,:)=round(mean(MK_accuracy),1)

TABLO(17,:)=round(mean(VOTE_accuracy),1)
TABLO(:,10)=round(mean(TABLO(:,1:9),2),1)
T=array2table(TABLO,...
    'RowNames',{'TPR Accuracy','TNR Accuracy','PPV Accuracy',...
    'NPV Accuracy','FPR Accuracy','FNR Accuracy','FDR Accuracy',...
    'FOR Accuracy','TS Accuracy','ACC Accuracy','BA Accuracy',...
    'F1 Accuracy','MCC Accuracy','FM Accuracy','BM Accuracy',...
    'MK Accuracy','Vote Accuracy'},...
    'VariableNames',{'Class1','Class2','Class3','Class4','Class5',...
    'Class6','Class7','Class8','Class9','Overall'});
writetable(T,'Kimia_2test_9train_Accuracies.xlsx','WriteRowNames',1);

            
            
            
            
            
            
            
            
                
                
            
        