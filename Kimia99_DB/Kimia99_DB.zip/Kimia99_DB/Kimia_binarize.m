for i=1:9
    for j=1:11,
        IM=imread(sprintf('trainimage%d_%d.png',i,j));
        IM(IM>0)=255;
        imwrite(IM,sprintf('KIMIA/trainimage%d_%d.png',i,j));
    end
end