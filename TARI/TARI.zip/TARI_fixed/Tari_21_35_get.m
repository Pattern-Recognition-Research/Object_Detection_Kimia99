clear all
load Tari.mat
for i=21:35
    for j=1:20
    V_21_35{i-20,j}=V{i,j};
    end
    
end
 clear i
 clear j
 clear V
 save Tari_21_35.mat