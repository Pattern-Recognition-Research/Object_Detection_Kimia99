clear all
close all
load Tari.mat
figure,
% V{24,3}=imrotate(V{24,3},180);
% V{34,5}=imrotate(V{34,5},180);
% V{34,6}=imrotate(V{34,6},180);
% V{34,7}=imrotate(V{34,7},180);
% V{24,8}=imrotate(V{24,8},180);
% 
% V{24,9}=imrotate(V{24,9},180);
% V{34,10}=imrotate(V{34,10},180);
% V{24,11}=imrotate(V{24,11},180);
%V{29,12}=flip(V{29,12},2);
% V{24,13}=imrotate(V{24,13},180);
% V{24,16}=imrotate(V{24,16},180);
% V{34,17}=imrotate(V{34,17},180);
% V{34,18}=imrotate(V{34,18},180);
% V{24,19}=imrotate(V{24,19},180);
for i=1:20
    subplot(5,4,i);
    imshow(V{35,i});
end
clear i
save Tari.mat

    